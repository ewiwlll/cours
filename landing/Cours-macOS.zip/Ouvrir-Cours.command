#!/usr/bin/env bash
# ============================================================
# Cours — Assistant d'ouverture et déblocage 1-Clic pour macOS
# ============================================================
clear
echo "🍏 Configuration et déblocage de Cours pour macOS..."

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# 1. Si Cours.app n'est pas encore dans Applications, copie automatique
if [ ! -d "/Applications/Cours.app" ] && [ -d "$DIR/Cours.app" ]; then
    echo "📦 Installation de Cours dans /Applications..."
    cp -R "$DIR/Cours.app" /Applications/
fi

# 2. Levée des restrictions de quarantaine Gatekeeper
if [ -d "/Applications/Cours.app" ]; then
    echo "⚡ Levée des sécurités macOS (xattr -cr)..."
    xattr -cr "/Applications/Cours.app" 2>/dev/null || true
    echo "🚀 Lancement de l'application Cours..."
    open "/Applications/Cours.app"
    echo "✓ Tout est prêt ! Vous pouvez fermer cette fenêtre."
elif [ -d "$DIR/Cours.app" ]; then
    xattr -cr "$DIR/Cours.app" 2>/dev/null || true
    open "$DIR/Cours.app"
else
    echo "❌ Cours.app introuvable."
fi
