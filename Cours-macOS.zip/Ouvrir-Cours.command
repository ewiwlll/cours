#!/usr/bin/env bash
# Script 1-Clic de lancement et levée de quarantaine Gatekeeper pour Cours
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
if [ -d "/Applications/Cours.app" ]; then
    TARGET="/Applications/Cours.app"
elif [ -d "$DIR/Cours.app" ]; then
    TARGET="$DIR/Cours.app"
else
    TARGET=""
fi

if [ -n "$TARGET" ]; then
    echo "Levée des restrictions de sécurité macOS sur Cours.app..."
    xattr -cr "$TARGET" 2>/dev/null || true
    echo "Lancement de Cours..."
    open "$TARGET"
else
    echo "Cours.app introuvable. Veuillez glisser Cours.app dans Applications."
fi
